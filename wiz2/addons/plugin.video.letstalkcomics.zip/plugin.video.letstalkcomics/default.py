# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Youtube Channel
# (c) 2015 - Simple TechNerd
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.letstalkcomics'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


channellist=[
        ("ComicsExplained", "user/fluidicbeats", 'https://yt3.ggpht.com/-OijD-ruBL6Y/AAAAAAAAAAI/AAAAAAAAAAA/Y3044xR9inI/s900-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Comic Drake", "user/ComicDrake", 'https://yt3.ggpht.com/-9KrrwC-7Ie0/AAAAAAAAAAI/AAAAAAAAAAA/ZeQfR-O6EDY/s900-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("VariantComics", "user/VariantComics", 'https://yt3.ggpht.com/-zleFl4vG_ww/AAAAAAAAAAI/AAAAAAAAAAA/gB5aeAxfIcE/s900-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Comicstorian", "user/comicstorian", 'https://yt3.ggpht.com/-7fOWmVVzpHU/AAAAAAAAAAI/AAAAAAAAAAA/7r-0us0td5M/s900-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("ComicPOP", "user/TVLittleHouse", 'https://yt3.ggpht.com/-IOzrH2iMdNw/AAAAAAAAAAI/AAAAAAAAAAA/hkhKKpznV2o/s900-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Caped-Joel", "user/CapedJoel", 'https://yt3.ggpht.com/-rWYXqPe7_ss/AAAAAAAAAAI/AAAAAAAAAAA/o0TO6TFH9Jg/s900-c-k-no-mo-rj-c0xffffff/photo.jpg'),		
]



# Entry point
def run():
    plugintools.log("letstalkcomics.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("letstalkcomics.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )



run()